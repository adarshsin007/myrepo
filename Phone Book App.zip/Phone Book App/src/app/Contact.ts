export class Contact {
    id: number = 0
    firstName: string = ''
    lastName: string = ''
    phoneNumber: string = ''
}